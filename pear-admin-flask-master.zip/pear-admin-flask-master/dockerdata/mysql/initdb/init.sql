CREATE DATABASE PearAdminFlask DEFAULT CHARSET utf8mb4 COLLATE utf8mb4_general_ci;;
